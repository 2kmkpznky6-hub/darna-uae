
const quizForm=document.querySelector('#quiz-form');
if(quizForm){quizForm.addEventListener('submit',e=>{e.preventDefault();let score=0;const answers=['b','a','c'];answers.forEach((a,i)=>{const picked=quizForm.querySelector(`input[name=q${i+1}]:checked`);if(picked&&picked.value===a)score++;});document.querySelector('#quiz-result').textContent=`Your score: ${score} / 3`;});}
