DARNA - Emirati Heritage Website
Files:
- index.html: homepage
- style.css: website design
- script.js: quiz interaction
- pages/: separate pages for each heritage topic

To publish with GitHub Pages:
1. Upload index.html, style.css, script.js, and the entire pages folder into the repository root.
2. Commit the files.
3. Open Settings > Pages.
4. Under Build and deployment choose Deploy from a branch.
5. Choose main and /(root), then Save.
6. Wait for GitHub Pages to publish the site.

Note: Photos are illustrative remote images and require an internet connection. The Heritage Guide/real AI integration is not included in this version. The quiz uses JavaScript.
